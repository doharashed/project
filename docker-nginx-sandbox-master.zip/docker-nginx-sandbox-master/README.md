# docker-nginx-sandbox
This is a sandbox to play with Nginx under docker container 
and if you changed he message in index.html file you could see the changes after building the docker image and container form the Docker file like 


#docker build -t testnginx .


#docker run -d -p 80:80 testnginx


